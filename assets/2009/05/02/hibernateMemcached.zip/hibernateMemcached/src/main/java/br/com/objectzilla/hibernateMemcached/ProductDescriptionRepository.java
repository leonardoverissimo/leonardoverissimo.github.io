package br.com.objectzilla.hibernateMemcached;

public interface ProductDescriptionRepository {
	
	ProductDescription getByBarCode(long barCode);
	
	void refreshProductInformation(ProductDescription product);

}
