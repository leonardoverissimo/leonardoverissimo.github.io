package br.com.objectzilla.hibernateMemcached.app;

import java.math.BigDecimal;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import br.com.objectzilla.hibernateMemcached.ProductDescription;
import br.com.objectzilla.hibernateMemcached.ProductDescriptionRepository;

public class Insert {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		XmlBeanFactory factory = new XmlBeanFactory(new ClassPathResource("applicationContext.xml"));

		PropertyPlaceholderConfigurer cfg = new PropertyPlaceholderConfigurer();
		cfg.setLocation(new ClassPathResource("all.properties"));

		cfg.postProcessBeanFactory(factory);

		ProductDescriptionRepository productRep = (ProductDescriptionRepository) factory
				.getBean("productDescriptionRepository");
		
		ProductDescription product = new ProductDescription();
		product.setBarCode(7891000053508L);
		product.setDescription("Achocolatado em Pó Nescau 2.0 NESTLÉ Lata 400g");
		product.setPrice(new BigDecimal("3.87"));
		product.setType("UN");
		
		productRep.refreshProductInformation(product);
	}
}
