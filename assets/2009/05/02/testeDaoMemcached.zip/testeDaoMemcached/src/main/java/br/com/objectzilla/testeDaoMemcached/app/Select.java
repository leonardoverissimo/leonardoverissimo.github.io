package br.com.objectzilla.testeDaoMemcached.app;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import br.com.objectzilla.testeDaoMemcached.ProductDescription;
import br.com.objectzilla.testeDaoMemcached.ProductDescriptionRepository;

public class Select {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		XmlBeanFactory factory = new XmlBeanFactory(new ClassPathResource("applicationContext.xml"));
		
		PropertyPlaceholderConfigurer cfg = new PropertyPlaceholderConfigurer();
		cfg.setLocation(new ClassPathResource("all.properties"));
		
		cfg.postProcessBeanFactory(factory);
		
		for (int i = 0; i < 10; i++) {

			long before = System.currentTimeMillis();

			ProductDescriptionRepository productRep = (ProductDescriptionRepository) factory
					.getBean("productDescriptionRepository");

			ProductDescription product = productRep.getByBarCode(7891000053508L);

			long after = System.currentTimeMillis();
			System.out.println("------------------------");
			System.out.println("Código de barras: " + product.getBarCode());
			System.out.println("Descrição: " + product.getDescription());
			System.out.println("Preço: " + product.getPrice());
			System.out.println("Tipo: " + product.getType());

			System.out.println();
			System.out.println("Delay: " + (after - before));
		}
	}
}
