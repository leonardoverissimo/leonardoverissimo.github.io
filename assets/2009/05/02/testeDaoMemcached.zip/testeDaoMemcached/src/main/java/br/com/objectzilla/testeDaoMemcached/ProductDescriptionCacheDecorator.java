package br.com.objectzilla.testeDaoMemcached;

import net.spy.memcached.MemcachedClient;

public class ProductDescriptionCacheDecorator implements ProductDescriptionRepository {
	
	private MemcachedClient memcachedClient;
	private int expiration;
	private ProductDescriptionRepository other;
	
	public ProductDescription getByBarCode(long barCode) {
		
		ProductDescription product = (ProductDescription) memcachedClient.get("product_descr/" + barCode);
		if (product == null) {
			product = other.getByBarCode(barCode);
			
			memcachedClient.add("product_descr/" + barCode, expiration, product);
		}
		return product;
	}

	public void refreshProductInformation(ProductDescription product) {
		other.refreshProductInformation(product);
		
		memcachedClient.delete("product_descr/" + product.getBarCode());
	}

	public void setMemcachedClient(MemcachedClient memcachedClient) {
		this.memcachedClient = memcachedClient;
	}
	
	public void setExpiration(int expiration) {
		this.expiration = expiration;
	}

	public void setOther(ProductDescriptionRepository other) {
		this.other = other;
	}
}
