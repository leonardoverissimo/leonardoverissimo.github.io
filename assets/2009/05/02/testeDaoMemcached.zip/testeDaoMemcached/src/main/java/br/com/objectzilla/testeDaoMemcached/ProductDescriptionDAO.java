package br.com.objectzilla.testeDaoMemcached;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class ProductDescriptionDAO implements ProductDescriptionRepository {
	
	private SimpleJdbcTemplate jdbcTemplate;
	
	public ProductDescription getByBarCode(long barCode) {
		
		return 
		jdbcTemplate.queryForObject(
				"SELECT bar_code, description, price, type " +
				"FROM product_description " +
				"WHERE bar_code = ?",
				new ParameterizedRowMapper<ProductDescription>() {
					public ProductDescription mapRow(ResultSet rs, int rowNum) throws SQLException {
						ProductDescription p = new ProductDescription();
						p.setBarCode(rs.getLong("bar_code"));
						p.setDescription(rs.getString("description"));
						p.setPrice(rs.getBigDecimal("price"));
						p.setType(rs.getString("type"));
						return p;
					}
				},
				barCode);
	}
	
	
	public void refreshProductInformation(ProductDescription product) {
		
		int affectedRows = jdbcTemplate.update(
				"UPDATE product_description " +
				"SET    description = ?, price = ?, type = ? " +
				"WHERE  bar_code = ?",
				product.getDescription(),
				product.getPrice(),
				product.getType(),
				product.getBarCode());
		
		if (affectedRows == 0) {
			jdbcTemplate.update(
					"INSERT INTO product_description( " +
					"    bar_code, description, price, type" +
					") VALUES (?, ?, ?, ?)",
					product.getBarCode(),
					product.getDescription(),
					product.getPrice(),
					product.getType());
		}
	}

	public void setDataSource(DataSource dataSource) {
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}
}
