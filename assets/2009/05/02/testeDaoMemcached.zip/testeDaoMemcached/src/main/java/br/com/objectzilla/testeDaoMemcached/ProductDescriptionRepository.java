package br.com.objectzilla.testeDaoMemcached;

public interface ProductDescriptionRepository {
	
	ProductDescription getByBarCode(long barCode);
	
	void refreshProductInformation(ProductDescription product);

}
