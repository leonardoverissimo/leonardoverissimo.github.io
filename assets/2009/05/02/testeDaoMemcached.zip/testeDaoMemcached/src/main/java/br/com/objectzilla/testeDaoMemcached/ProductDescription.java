package br.com.objectzilla.testeDaoMemcached;

import java.io.Serializable;
import java.math.BigDecimal;

public class ProductDescription implements Serializable {
	private static final long serialVersionUID = 5928196686674902152L;

	private long barCode;
	
	private String description;
	
	private BigDecimal price;
	
	private String type;

	public long getBarCode() {
		return barCode;
	}

	public void setBarCode(long barCode) {
		this.barCode = barCode;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}
