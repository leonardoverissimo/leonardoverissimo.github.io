create table product_description (
	bar_code    BIGINT primary key,
	description VARCHAR(100),
	price       DECIMAL (10,2),
	type        VARCHAR(10)
);